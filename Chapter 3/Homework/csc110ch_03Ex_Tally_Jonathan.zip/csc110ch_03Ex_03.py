# Write a program that uses a for loop to print
#     One of the months of the year is January
#     One of the months of the year is February
#     ...

for m in ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']:
    months =  "One of the months of the year is " + m
    print(months)